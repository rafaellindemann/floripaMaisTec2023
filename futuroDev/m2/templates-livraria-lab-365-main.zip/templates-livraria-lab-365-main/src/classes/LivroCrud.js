class LivroCrud {

    constructor() {
        this.filePath = './src/files/livros.json';
    }

}

module.exports = LivroCrud;