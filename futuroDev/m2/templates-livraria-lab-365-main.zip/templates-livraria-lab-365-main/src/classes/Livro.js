class Livro {

    constructor() {
       
    }

}

module.exports = Livro;