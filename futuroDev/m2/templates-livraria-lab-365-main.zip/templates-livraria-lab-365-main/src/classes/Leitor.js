class Leitor {

    constructor() {
       
    }

}

module.exports = Leitor;