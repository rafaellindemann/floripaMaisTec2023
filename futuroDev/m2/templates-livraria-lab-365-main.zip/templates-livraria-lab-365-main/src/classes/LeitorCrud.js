class LeitorCrud {

    constructor() {
       
    }

}

module.exports = LeitorCrud;