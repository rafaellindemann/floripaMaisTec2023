class Auditorio {

    constructor() {

    }

}

module.exports = Auditorio;