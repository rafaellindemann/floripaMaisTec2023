class AuditorioCrud {
    
    constructor() {
        this.filePath = './src/files/auditorios.json';
    }

}

module.exports = AuditorioCrud;