class Instrumento {

    constructor() {
       
    }

}

module.exports = Instrumento;