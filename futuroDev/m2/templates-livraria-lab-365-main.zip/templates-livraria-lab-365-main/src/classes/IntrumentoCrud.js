class InstrumentoCrud {

    constructor() {
       
    }

}

module.exports = InstrumentoCrud;