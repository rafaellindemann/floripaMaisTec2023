const { Server } = require('./server')

new Server()
