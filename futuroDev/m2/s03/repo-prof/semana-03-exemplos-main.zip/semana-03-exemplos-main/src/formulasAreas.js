function calcularAreaTriangulo(altura, base) {
    const area = (base * altura) / 2
    return area
}

module.exports = {
    calcularAreaTriangulo
}
