function calcularPerimetroTriangulo(ladoA, ladoB, ladoC){
    // return ladoA + ladoB + ladoC
    const perimetro = ladoA + ladoB + ladoC
    return perimetro
}

module.exports = {
    calcularPerimetroTriangulo
}