# Exemplos da semana 13 no módulo 1

- Aula 1
  - Revisão de Hooks
  - Estado global e ContextAPI
- Aula 2
  - Formulários com React Hook Form
  - Convenção de commits
